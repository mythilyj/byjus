<?php
echo "First Name: ".$_POST['firstname'];
?>

</br>

<?php
echo "Surname: ".$_POST['lastname'];
?>

</br>

<?php
echo "Gender: ".$_POST['gender'];
?>

</br>

<?php
echo "Console: ".$_POST['Console'];
?>

</br>


<?php
require_once 'config.php';
?>